<?php
require_once  plugin_dir_path (__FILE__) . 'включает/SyncProductsJob.php' ;
require_once  plugin_dir_path (__FILE__) . 'включает/ProductImportWpsync.php' ;
require_once ( wp_normalize_path ( ABSPATH ). 'wp-load.php' );

новый  ProductImportWpsync ();

register_activation_hook (__FILE__, 'activationProductImport' );
функция  активацииProductImport () {

    wp_clear_scheduled_hook ( 'my_hourly_event' );
    // Проверим, нет ли уже задачи с таким же хуком

    // добавим новую мебель cron
    wp_schedule_event ( время (), 'ежечасно' , 'my_hourly_event' );
}

register_deactivation_hook (__FILE__, 'deactivationProductImport' );
функция  деактивацииProductImport () {
    wp_clear_scheduled_hook ( 'my_hourly_event' );
}