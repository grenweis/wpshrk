<?php


класс  SyncProductsJob
{
    const  GET_PRODUCTS_API_LINK = 'https://my.api.mockaroo.com/products.json?key=89b23a40' ;

    публичная  функция  sync_products ()
    {
        $ product_data = json_decode ( $ this -> getProductsJson ());
        если (! $ product_data )
            возврат ;
        //$this->сохранитьпродукт($product_data[0]);
        foreach ( $ product_data  как  $ product ) {
            $ this -> saveProduct ( $ product );
        }

    }

    приватная  функция  getProductsJson ()
    {
        попробуй {
            // вернуть file_get_contents(self::GET_PRODUCTS_API_LINK);
            вернуть  file_get_contents ( 'E:\Work\project\temp.json' );
        } поймать ( Throwable  $ ex ) {
            echo  'Не удалось получить json: ' . $ ex -> getMessage ();
            вернуть  ноль ;
        }
    }

    закрытая  функция  unpublishProductBySKU ( $ sku )
    {
        $ product_id = wc_get_product_id_by_sku ( $ sku );
        $ product_post = массив (
            'ID' => $ product_id ,
            'post_type' => 'продукт' ,
            'post_status' => 'черновик'
        );
        wp_insert_post ( $ product_post );
    }

    частная  функция  getExistingSKUs () {
        $ аргументы = массив (
            'post_type' => 'продукт' ,
            'сообщений_на_странице' => - 1
        );

        $ wcProductsArray = get_posts ( $ args );

        $ существующие SKU = массив ();
        если ( количество ( $ wcProductsArray )) {
            foreach ( $ wcProductsArray  as  $ productPost ) {
                $ currentSKU = get_post_meta ( $ productPost -> ID , '_sku' , true );
                array_push ( $ existingSKUs , $ currentSKU );
            }
        }
        вернуть  $ существующие SKU ;
    }

    закрытая  функция  saveIncomingProducts ( $ productData )
    {
        $ сохраненныеSKUs = массив ();
        foreach ( $ productData  как  $ product ) {
            $ this -> saveProduct ( $ product );
            array_push ( $ saveSKUs , $ product -> sku );
        }
        вернуть  $ сохраненных SKU ;
    }

    закрытая  функция  saveProduct ( $ productToSave )
    {
        $ sku = $ productToSave -> sku ;
        $ product_post = массив (
            'ID' => wc_get_product_id_by_sku ( $ sku ),
            'post_title' => $ productToSave -> имя ,
            'post_content' => $ productToSave -> описание ,
            'post_type' => 'продукт' ,
            'post_status' => 'опубликовать'
        );
        $ productId = wp_insert_post ( $ product_post );

        если ( $ productId ) {
            update_post_meta ( $ productId , '_price' , $ productToSave -> цена );
            update_post_meta ( $ productId , '_sku' , $ productToSave -> sku );
            update_post_meta ( $ productId , '_stock' , $ productToSave -> in_stock );
            update_post_meta ( $ productId , "_manage_stock" , "yes" );
            update_post_meta ( $ productId , '_product_image_gallery' , $ productToSave -> picture );
        }
    }
}