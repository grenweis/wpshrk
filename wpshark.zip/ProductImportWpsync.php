<?php


класс  ProductImportWpsync
{

    публичная  функция  __construct ()
    {
        если ( определено ( 'DOING_CRON' ) && DOING_CRON ) {
            add_action ( 'my_hourly_event' , array ( new  SyncProductsJob (), 'sync_products' ));
        }
    }

}